namespace CommandsService.Dtos
{
    public class GenericEventDto
    {
        public string Event { get; set; }
    }
}